<?php
session_start();
$id=$_SESSION['id'];
include 'db.php';
$sql1="UPDATE users SET status=0 WHERE id='$id'";
$result1=$conn->query($sql1);
session_destroy();
header('Location:index.php')
?>