<?php
                    session_start();
$id=$_SESSION["id"];
$u_id=$_SESSION["u_id"];
if(!isset($id))
{
	include 'login.php';
}
include 'db.php';
# Fetch username1 
$sql1="SELECT * FROM users WHERE id='$id'";
$result1=$conn->query($sql1);
if($row1=$result1->fetch_array())
{
	$username1=$row1['username'];
}
# Fetch Username 2
$sql2="SELECT * FROM users WHERE id='$u_id'";
$result2=$conn->query($sql2);
if($row2=$result2->fetch_array())
{
	$username2=$row2['username'];
	$status=$row2['status'];
	
}   
                  //onlline /offline indicator..........                      
                        if($status==1)
                      { 
					  echo $username2."<img src='online.png' alt='online' title='online' width='10px' style='margin-left:20px;'>";
					  }
					  else
					  {
						  echo $username2."<img src='offline.jpg' alt='offline' title='offline' width='10px' style='margin-left:20px;'>";
					  }
			    //onlline /offline indicator..........                 
					 $sql="SELECT * FROM chat WHERE u_id='$u_id'  AND u_id1='$id' OR u_id='$id'  AND u_id1='$u_id'  ORDER BY id DESC LIMIT 8" ;
					 $result=$conn->query($sql);
					 while($row=$result->fetch_array())
					 {
						  
						 if($row['username1']==$username1)
						 {
						 echo "<div id='sender'><b>";
						 
						      
						 echo $row['message'];
						 echo "</b><br></div>";
						 }
						 else
						 {      
							  echo "<div id='receiver'><b>";
						       
						 echo $row['message'];
						 echo "</b></div>";
						 }
					 }
					
?>