<?php
session_start();;
if(!isset($_SESSION["id"]))
{
	header('Location:index.php');
}
?>
<!Doctype html>
<html>
 <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="author" content="Karan Soni">
  <meta name="keyword" content="buddybook,bb,bbook,skaran921,skaran">
  <meta name="description" content="Buddy Book....Chat With Your Buddy">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="main.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="header.css" rel="stylesheet">
		<link rel="icon" href="logo.png">
  <title>
   Buddy-Book
  </title>
  </head>
  <!---------------------------Head Close And Body Of Page Start here------------------------------->
  <body  class="container-fluid">
  <div class="header">
  <div class="row" style="background-color:#f6f6f6">
    <div class="col-sm-3">
	<img src="logo.png" class="img-fluid" style="width:100px;cursor:pointer;" alt="BuddyBook" title="BuddyBook">
	</div>
	    <div class="col-sm-3">
	        <H1 style="margin-top:30px;color:slateblue;">Buddy Book</H1>
	    </div>
		
		  <div class="col-sm-3">
		   <div class="row">
		    <form class="form-group">
			<div class="input-group">
			<input type="search" name="search" class="form-control" style="margin-top:20px;">
			<span class="input-group-btn">
			<button type="button" onclick="document.forms[0].submit();" class="btn btn-secoundary" style="margin-top:20px;cursor:pointer">
			Search
			</button>
			</span>	
            </form>
			</div>
			 </div>
			</div>
			  <div class="col-sm-3">
			   <form method="post" action="logout.php">
			   <input type="submit" value="logout"  class="btn btn-danger" style="margin-top:20px;cursor:pointer;">
			   </form>
			  </div>
       </div>
		  </div>
		
  </div>
  </body>
 <?php 
 include 'db.php';
 
 ?>
  </html>