<?php

$conn= mysqli_connect("localhost","root","","buddybook");
if(!$conn)
{
	 die("Connection Failed!!!".mysqli_connect_error());
}
?>
