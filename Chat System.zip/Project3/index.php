<?php 
   session_start();
   if(isset($_SESSION['id']))
   {
	   header('Location:main.php');
   }
?>
<!Doctype html>
<html>
 <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="author" content="Karan Soni">
  <meta name="keyword" content="buddybook,bb,bbook,skaran921">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="main.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">

		<link rel="icon" href="logo.png">
  <title>
   Buddy-Book
  </title>
  </head>
  <body class="container">
   <div class="header">
    <div class="row" style="background-color:whitesmoke;">
	
	 <div class="col-sm-2">
	 <img src="logo.png" class="img-fluid" style="width:100px;cursor:pointer;" alt="BuddyBook" title="BuddyBook">
	 </div>
	  <div class="col-sm-3">
	  <H1 style="margin-top:30px;color:slateblue;">Buddy Book</H1>
	  </div>
	   <div class="col-sm-3">
	   <!----------------Login Form Start Here................--------------------------->
	   <form action="login.php" method="post">
	      <div class="form-group" style="margin-top:30px;">
		 <input type="text" id="lf1" name="login_id" placeholder="Enter User Id Here...." required class="form-control" title="Enter User Id Here.">
		</div>
		</div>
		<div class="col-sm-3"style="margin-top:30px;">
	    <div class="form-group">
		 <input type="password" id="lf2" name="password" placeholder="Enter Password Here...." required class="form-control" title="Enter Password.">
		</div>
		</div>
		<div class="col-sm-1"style="margin-top:30px;">
	    <div class="form-group">
		<input type="submit" id="lf3" name="login" class="btn btn-primary" value="Login">
		
		</div>
		</div>
		
		</form>
		    
			<?php
               if(isset($_SESSION['id']))
			   { 
		          $_SESSION['id'];
				 
			   }				   
			   else
			   {
				    echo "<b>You Are Not Logged In!!!</b>";
			   }
			?>
	   </div>
	</div>
   </div>
   
   <!--------------------------header  close here------------------------------->
   <div class="row" style="background-color:cornsilk; margin-top:10px;">
   <div class="col-sm-5">
   <img src="bb.png" title="buddybook" alt="buddybook" class="img-fluid">
   <br>
   <div class="row"style="background-color:lightyellow; margin-top:10px;margin-left:12px;">
   <b style="color:steelblue">Forgot Password</b>
   </div>
   <div class="row"style="background-color:lemonchiffon; margin-top:10px;margin-left:12px;">
   <form class="form-group" action="forgot.php" method="post" style="width:300px;margin-top:20px;">
   <input type="text" id="lf1" name="login_id" placeholder="Enter User Id Here...." required class="form-control" title="Enter User Id Here.">
	<br>
	<input type="password" id="lf2" name="question" placeholder="Your Best Friend Name?" required class="form-control" title="Enter Password.">
	<input type="submit" id="lf3" name="login" class="btn btn-primary" value="Login" style="margin-left:10px;">
     </form>
   
   </div>
   </div>
   
   <!---------------signup---------------div----------start--------->
   <div class="col-sm-7" style="float:right;">
   <h1 style="margin-top:20px;margin-bottom:-40px;"><center>Sign Up</center></h1><br>
   
	   <!----------------Sign Up Form Start Here................--------------------------->
	   <form action="signup.php" method="post" style="float:right;margin-right:50px">
	      <div class="form-group" style="margin-top:30px;">
		  <input type="text" id="suf1" name="name" placeholder="Enter User Full Name Here..." required class="form-control" title="Enter User Id Here.">
		  <b>Male:</b><input type="radio" id="suf2" name="gender" value="male" required title="Male">
		  <b>Female:</b><input type="radio" id="suf2" name="gender" value="female" required title="FeMale">
		  <b>Others:</b><input type="radio" id="suf2" name="gender" value="other" required title="Others">
		 <input type="text" id="suf3" name="login_id" placeholder="Enter User Id Here...." required class="form-control" title="Enter User Id Here.">
	    <input type="password" id="suf4" name="password" placeholder="Enter Password Here...." required class="form-control" title="Enter Password.">
		<!----------------------------------------Date  Section Start Here--------------------------------->
		<b>Enter Date Of Birth:</b>
		
		<select id="suf5" name="date" placeholder="Enter Date Here..e.g.04?" required class="form-control" title="Enter Date." style="padding:0px;">
		<option>Select a Date</option>
		<?php 
		  $a;
		  for($a=1;$a<=31;$a++)
		  {
			  echo "<option>$a</option>";
			  
		  }
		?>
		</select>
		<select id="suf6" name="month" placeholder="Enter Month Here..e.g.05" required class="form-control" title="Enter Month." style="padding:0px;">
		<option>Select a Month</option>
		<?php 
		  $a;
		  for($a=1;$a<=12;$a++)
		  {
			  echo "<option>$a</option>";
			  
		  }
		?>
		</select>
		<select id="suf7" name="year" placeholder="Enter Year Here..e.g.2000" required class="form-control" title="Enter Year." style="padding:0px;">
		<option>Select a Year</option>
		<?php 
		  $a;
		  for($a=1900;$a<=2050;$a++)
		  {
			  echo "<option>$a</option>";
			  
		  }
		?>
		</select>
		
		
		     
		  
		<input type="text" id="suf8" name="city" placeholder="Your City Name?" required class="form-control" title="Enter Your City Name">
		<input type="text" id="suf9" name="state" placeholder="Your State Name?" required class="form-control" title="Enter Your State Name.">
		<input type="text" id="suf10" name="country" placeholder="Your Country Name?" required class="form-control" title="Enter Your Country Name">
		<input type="tel" id="suf11" name="mobile" placeholder="Your Mobile No.? If Applicable"  class="form-control" title="Enter Your Mobile No..">
		<b>Security Question:</b>
		<input type="text" id="suf12" name="question" placeholder="Who is Your Best Friend?" required class="form-control" title="Enter Ans. OF Question">
		<input type="submit" id="suf13" name="signup" class="btn btn-danger" value="Sign Up">
		
		</div>
		</form>
		</div>
				 
	   </div>
   </div>
   
  
  <!--------------------------footer Start here------------------------------->
   <div class="row" style="background-color:dimgray; margin-top:10px;" id="footer">
   <div class="col-sm-12">
   <h3><center>
   <b>This Website Designed And Developed By <a href="skaran.jimdo.com">Karan Soni.</a></center></b></h3>
   </div>
   </div>
  </body>
</html>
