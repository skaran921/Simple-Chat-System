<?php 
session_start();
$id=$_SESSION["id"];
if(!isset($id))
{
	include 'login.php';
}
//if(empty($_POST["u_id"]))
//{
//	header("Location:main.php");
//}

?>



<!Doctype html>
<html>
 <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="main.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="notification.css" rel="stylesheet">
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="notification.js"></script>
    <link href="chat.css" rel="stylesheet">
		<link rel="icon" href="logo.png">
		<script src="ajax.js"></script>
  <title>
   Chat
  </title>
  </head>
  <body onload="ajax()">
<div class="container">
   <div class="header" style="margin-top:10px;">
    <div class="row" style="background-color:whitesmoke;">
	
	 <div class="col-sm-2">
	 <a href="index.php" title="Home">
	 <img src="logo.png" class="img-fluid" style="width:100px;cursor:pointer;" alt="BuddyBook" title="BuddyBook"></a>
	 </div>
	  <div class="col-sm-3">
	  <H1 style="margin-top:30px;color:slateblue;">Buddy Book</H1>
	  </div>
	  <div class="col-sm-4">
<?php
include 'db.php';
$id=$_SESSION['id'];
$sql="SELECT * FROM 	users WHERE id='$id'";
$result=$conn->query($sql);
while($row=$result->fetch_assoc())
{
	echo"<b>Welcome ";
	$username1=$row['username'];
	echo $row['name'];
	echo "</b>";
	$date=date('H');
	//echo $date;
	if($date>=4 && $date<12 )
	{
		echo '<br><b>Good Morning!!!';
	}
	else if($date>=12 && $date<=16)
	{
		echo "<br><b>Good AfterNoon!!!</b>";
	}
	else if($date>16 && $date<=19)
	{
		echo "<br><b>Good Evening!!!</b>";
	}
	else
	{
		echo "<br><b>Hiiii!!!</b>";
	}
	
}
?>
</div>
<div class="col-sm-3">
<form class="form-group" action="logout.php">
<button class="btn btn-primary" style="margin-top:20px;cursor:pointer;"onclick="window.location.href='main.php';">Back</button> 
<button class="btn btn-danger" style="margin-top:20px;cursor:pointer;">Log Out</button> 
</form>
</div>
</div>
</div>
<!-------Header Close Here and 2nd part of page Start Here----------------->

<?php
include 'db.php';

 $u_id=$_SESSION['u_id'];
$sql="SELECT * FROM  users where id='$u_id'";
$result=$conn->query($sql);
while($row=$result->fetch_array()):
$_SESSION['u_id']=$row['id'];
?>
<?php $username2=$row['username'];?>
<div class="row">
<center><h2>Let's Chat With<u> <?php echo $row["username"];?></u></h2></center>
<?php endwhile;?>
   <div class="col-sm-4">
         <div class="main">
           <div class="message"  id="message">
		          
		            </div>
               <div class="chat">
			   <!-------------------------------------------------Form Start Here---------------------------------------->
			       <form class="form-group" id="chat-form" action="chat.php" method="post" >
				      <input type="text" class="form-control" placeholder="Enter Your Message Here" name="message" required autofocus>
					  <button  type="submit" class="btn btn-warning" name="send" >Send</button>
				   </form>
				   <!---------------------------------------------Form  Close Here------------------------------------------->
				   <!--------------------------------------------notification------------------------------------------------>
				    <div id="alert-popover">
					    <div class="wrapper">
						   <div class="content">
						   </div>
						</div>
					</div>
				   <!--------------------------------------------notification close here-------------------------------------->
				   <?php
				        if(isset($_POST["send"]))
						{
							
				        //echo $username1;
						//echo $username2;
						//echo "hr".$u_id;
						include 'db.php';
						 $message=addslashes($_POST["message"]);
				      $sql="INSERT INTO chat(username1,username2,message,u_id,u_id1,status)VALUES('$username1','$username2','$message','$u_id','$id',1)";
					  $result=$conn->query($sql);
					      if($result==TRUE)
						  {
							   echo 
							   "<div class='alert alert-success'>
							        <embed src='demonstrative.mp3' hidden='true' loop='false' autoplay='true'>
							        <b>Message Send!!!</b>									
							   </div>";
							   
							   							   
						  }
						  else
						  {
							   echo "<div class='alert alert-danger'>
							        <b>Message Not Send...error!!!</b>
									</div>";
						  }
						}
				   ?>
               </div>
           </div>
         </div>
	</div>	 
</div>		 
<!-----------------------------------------------CSS Start Here--------------------------------------->
   <style>
   .message
   {
	   width:300px;
   }
   #sender
   {
	 font-weight:bold;
	 margin-top:20px;
	 text-align:right;
	 
   }
   #sender b
   {
	   
	   background-color:green;
	  color:white;
	  font-weight:bold;
	  font-family:lucida handwriting;
	  text-align:right;
	  padding:5px;
	   border-width:2px;
	   border:color:red;
	   border-style:solid;
	   border-radius:20px;
	  margin-right:40px;
	
   }
   
#receiver
{
	 
	 text-align:left;
	 margin-top:20px;
	 
}	
#receiver b
{
	 background-color:orange;
	  color:white;
	  padding:5px;
	   border-width:2px;
	   border:color:silver;
	   border-style:outset;
	   border-radius:20px;
	 text-align:left;
	 margin-top:10px;
      margin-left:20px;	 
}	
.main
{
	background-color:#f2f2f2;
	margin-left:10px;
	width:270px;
}
</style>  
<!---------------------------------------------------------End Css----------------------------------------------->