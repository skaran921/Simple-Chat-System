<?php 
session_start();
$id=$_SESSION["id"];
if(!isset($id))
{
	include 'login.php';
}


?>
<!Doctype html>
<html>
 <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="main.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="chat.css" rel="stylesheet">
		<link rel="icon" href="logo.png">
  <title>
   Buddy-Book
  </title>
  </head>
  <body>
<div class="container">
   <div class="header" style="margin-top:10px;">
    <div class="row" style="background-color:whitesmoke;">
	
	 <div class="col-sm-2">
	 <img src="logo.png" class="img-fluid" style="width:100px;cursor:pointer;" alt="BuddyBook" title="BuddyBook">
	 </div>
	  <div class="col-sm-3">
	  <H1 style="margin-top:30px;color:slateblue;">Buddy Book</H1>
	  </div>
	  <div class="col-sm-4">
<?php
include 'db.php';
$id=$_SESSION['id'];
$sql="SELECT * FROM 	users WHERE id='$id'";
$result=$conn->query($sql);
while($row=$result->fetch_assoc())
{
	echo"<b>Welcome ";
	echo $row['name'];
	echo "</b>";
	$date=date('H');
	//echo $date;
	if($date>=4 && $date<12 )
	{
		echo '<br><b>Good Morning!!!';
	}
	else if($date>=12 && $date<=16)
	{
		echo "<br><b>Good AfterNoon!!!</b>";
	}
	else if($date>16 && $date<=19)
	{
		echo "<br><b>Good Evening!!!</b>";
	}
	else
	{
		echo "<br><b>Hiiii!!!</b>";
	}
	
}
?>
</div>
<div class="col-sm-3">
<form class="form-group" action="logout.php">
<button type="submit" class="btn btn-danger" style="margin-top:20px;cursor:pointer;">Log Out</button> 
</form>
</div>
</div>
</div>
<!-------Header Close Here and 2nd part of page Start Here----------------->
<div class='row'style="margin-top:10px;background-color:lightyellow">
  <div class="col-sm-5">

	  <div class="table-responsive">
	  <table border="5" class="table table-striped">
	  <th>Username</th><th>Name</th><th>Message</th>
	           <?php 
	     $sql="SELECT * FROM users WHERE id !='$id' ORDER BY username";
		 $result=$conn->query($sql);
		 while($row=$result->fetch_array()):
	  ?>
	  <form action="chat1.php" method="post">
	  
	  <input type="hidden" name="u_id" value="<?php echo $row['id']?>">
	  <tr><td><?php echo $row['username']?></td><td><?php echo $row['name']?></td>
	       <td><button  onclick="form.submit();" class="btn btn-primary" >
		   <img src="icon/mail-white.png" alt="Send Message" title="Send Message" class="img-fluid">
		   </button></td></tr>
		    </form>
	   <?php endwhile; ?>
	  </table>
	 
	  </div>
  </div>
           
  </div><!------------row close here------------------>
  </div><!---------containter close here-------------->
  </body>
  </html>