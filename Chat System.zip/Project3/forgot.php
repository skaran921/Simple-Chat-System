<?php
session_start();
include 'db.php';
$login_id=$_POST["login_id"];
$password=$_POST["question"];
$sql="SELECT * FROM users WHERE username='$login_id' AND question='$password'";
$result=$conn->query($sql);
if(!$row = $result->fetch_assoc())
{
	echo "<b style='color:red'>Your User Name OR Password Not Match!!!... Try Again..</b>";

	
}
else
{
	$_SESSION['id']=$row['id'];
	include 'main.php';
	exit();
}
header('Location:index.php');
?>