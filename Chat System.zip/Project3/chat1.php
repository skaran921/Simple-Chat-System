<?php
session_start();
include 'db.php';
$u_id=$_POST["u_id"];
$_SESSION["u_id"]=$u_id;
header('Location:chat.php');
?>