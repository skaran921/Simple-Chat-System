<?php
session_start();
include 'db.php';
$name=$_POST["name"];
$gender=$_POST["gender"];
$login_id=$_POST["login_id"];
$password=$_POST["password"];
$date=$_POST["date"];
$month=$_POST["month"];
$year=$_POST["year"];
$city=$_POST["city"];
$state=$_POST["state"];
$country=$_POST["country"];
$mobile=$_POST["mobile"];
$question=$_POST["question"];

$sql="INSERT INTO users(name,gender,username,password,date,month,year,city,state,country,mobile,question)
 VALUES('$name','$gender','$login_id','$password','$date','$month','$year','$city','$state','$country','$mobile','$question')";
 $sql1="SELECT * FROM users WHERE username='$login_id'";
$result1=$conn->query($sql1);
$row=$result1->fetch_assoc();
if(isset($_POST['signup']))
{
 if(!$row)
 {
	$result=$conn->query($sql);
	if($result==TRUE)
	{
    die("<b style='color:green'>New Account Created!!!</b>");
	}
    else
	{
		die('<b>Opps Error..!!!</b>'.mysqli_connect_error());
	}		
 }
else
{
	die('<b>User Name Already Exists!!!... Try Diffrent Useraname..</b>');
}
}
header("Location: index.php");



?>