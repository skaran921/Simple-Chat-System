<?php
session_start();
include 'db.php';
$login_id=$_POST["login_id"];
$password=$_POST["password"];
$sql="SELECT * FROM users WHERE username='$login_id' AND password='$password'";
$sql1="UPDATE users SET status=1 WHERE username='$login_id' AND password='$password' ";
$result=$conn->query($sql);
$result1=$conn->query($sql1);
if(!$row = $result->fetch_assoc())
{
	echo "<b style='color:red'>Your User Name OR Password Not Match!!!... Try Again..</b>";
	
}
else
{
	$_SESSION['id']=$row['id'];
	header('Location:main.php');
	exit();
}
header('Location:index.php');
?>